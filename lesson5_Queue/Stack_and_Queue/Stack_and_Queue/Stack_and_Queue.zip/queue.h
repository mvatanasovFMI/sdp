#ifndef _QUEUE_H_
#define _QUEUE_H_

#include "generic-data-structure.h"

template <typename T>
class Queue : public GenericDataStructure<T>
{
};

#endif // !_QUEUE_H_

