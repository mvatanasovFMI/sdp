#ifndef _STACK_H_
#define _STACK_H_

#include "generic-data-structure.h"

template <typename T>
class Stack : public GenericDataStructure<T>
{
};

#endif // !_STACK_H_

